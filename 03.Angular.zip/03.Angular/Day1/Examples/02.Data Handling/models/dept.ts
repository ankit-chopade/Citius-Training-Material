export class Dept
{
  deptno:number = 0;
  dname:string  = "";
  loc:string  = "";
}
